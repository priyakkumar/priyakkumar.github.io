
var headerText = "Dillo Day Bingo";
var introText = "You probably don't need much to spice up your Dillo Day experience. It's already going to be a crazy, fantastic, otherworldly experience full of a type of debauchery you won't ever otherwise see at Northwestern. But perhaps the endless alcohol consumption and sweaty moshing on the Lakefill doesn't excite you to the same level that it does for the rest of the student body. THIS IS VERY LONG";

var winText = "<p>You win!</p>";

var JSONBingo = {"squares": [
        {"square": "Keg stand for 30 seconds or longer"},
        {"square": "Get on the shoulders of a basketball player"},
        {"square": "Have sexual relations in a port-o-potty"},
        {"square": "Take a selfie with a high-schooler"},
        {"square": "Get on at least four different roofs of tailgate houses"},
        {"square": "Take a selfie with a TA"},
        {"square": "Mud wrestling (if it rains/mud is present. If not, regular wrestling is acceptable.)"},
        {"square": "Pass out on the lakefill"},
        {"square": "Crowdsurf"},
        {"square": "Have at least half of your skin covered in mud"},
        {"square": "Smoke a joint with one of the performers (if you are on Mayfest, it doesn't count)"},
        {"square": "Take a selfie with a police officer or a member of security"},
        {"square": "Slip-n-slide"},
        {"square": "Collect four loose articles of clothing"},
        {"square": "Recite every syllable of Chance the Rapper's 'Juice' as he performs it"},
        {"square": "End up in the library"},
        {"square": "Get a visitor from a Big Ten school to admit that Northwestern knows how to party too."},
        {"square": "Drink a form of alcohol from North America, South America, Asia and Europe"},
        {"square": "Plank on five Northwestern structures"},
        {"square": "Find a sober person and get them to dance like they've had 15 shots"},
        {"square": "Take of the picture of the youngest-looking townie attempting to get in with a fake I.D."},
        {"square": "Slap the bag for at least 50 seconds"},
        {"square": " Win at least six total games of beer pong"},
        {"square": "For men: get at least five girls on your shoulders. For women: get on at least five guys' shoulders"},    	
        {"square": "Successfully perform a backflip"},    	
        {"square": "Document a high schooler attempting to sneak in through the rocks"}   	
    ]
};
